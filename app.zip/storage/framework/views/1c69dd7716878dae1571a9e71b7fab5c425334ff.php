<div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        <ul aria-expanded="false">
							<li><a href="<?php echo url('/index');; ?>">Dashboard</a></li>
							<li><a href="<?php echo url('/analytics');; ?>">Analytics</a></li>
                            
                            <?php if(session('type')!='User'): ?>
                            <li><a href="<?php echo url('/users');; ?>">Users</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo url('/category');; ?>">Categories</a></li>
                            <li><a href="<?php echo url('/deals');; ?>">Deals</a></li>
							<!-- <li><a href="<?php echo url('/review');; ?>">Review</a></li> -->
                            <!--li><a href="<?php echo url('/ecom-product-list');; ?>">Product List</a></li-->
                            <li><a href="<?php echo url('/products');; ?>">Products</a></li>
							<!--li><a href="<?php echo url('/order');; ?>">Order</a></li-->
							<li><a href="<?php echo url('/order-list');; ?>">Order List</a></li>
							<!-- <li><a href="<?php echo url('/customer-list');; ?>">Customer List</a></li> -->
                            <!-- <li><a href="<?php echo url('/ecom-checkout');; ?>">Checkout</a></li>
							<li><a href="<?php echo url('/ecom-invoice');; ?>">Invoice</a></li>
							<li><a href="<?php echo url('/ecom-customers');; ?>">Customers</a></li> -->
							<!--li><a href="<?php echo url('/element');; ?>"> Element</a></li-->
						</ul>
                    </li>
                    
                    <!-- <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
						<i class="flaticon-381-television"></i>
							<span class="nav-text">Apps</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo url('/app-profile');; ?>">Profile</a></li>
                            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Email</a>
                                <ul aria-expanded="false">
                                    <li><a href="<?php echo url('/email-compose');; ?>">Compose</a></li>
                                    <li><a href="<?php echo url('/email-inbox');; ?>">Inbox</a></li>
                                    <li><a href="<?php echo url('/email-read');; ?>">Read</a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo url('/app-calender');; ?>">Calendar</a></li>
							<li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Shop</a>
                                <ul aria-expanded="false">
                                    <li><a href="<?php echo url('/ecom-product-grid');; ?>">Product Grid</a></li>
									<li><a href="<?php echo url('/ecom-product-list');; ?>">Product List</a></li>
									<li><a href="<?php echo url('/ecom-product-detail');; ?>">Product Details</a></li>
									<li><a href="<?php echo url('/ecom-product-order');; ?>">Order</a></li>
									<li><a href="<?php echo url('/ecom-checkout');; ?>">Checkout</a></li>
									<li><a href="<?php echo url('/ecom-invoice');; ?>">Invoice</a></li>
									<li><a href="<?php echo url('/ecom-customers');; ?>">Customers</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Charts</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo url('/chart-flot');; ?>">Flot</a></li>
                            <li><a href="<?php echo url('/chart-morris');; ?>">Morris</a></li>
                            <li><a href="<?php echo url('/chart-chartjs');; ?>">Chartjs</a></li>
                            <li><a href="<?php echo url('/chart-chartist');; ?>">Chartist</a></li>
                            <li><a href="<?php echo url('/chart-sparkline');; ?>">Sparkline</a></li>
                            <li><a href="<?php echo url('/chart-peity');; ?>">Peity</a></li>
                        </ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-internet"></i>
							<span class="nav-text">Bootstrap</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo url('/ui-accordion');; ?>">Accordion</a></li>
                            <li><a href="<?php echo url('/ui-alert');; ?>">Alert</a></li>
                            <li><a href="<?php echo url('/ui-badge');; ?>">Badge</a></li>
                            <li><a href="<?php echo url('/ui-button');; ?>">Button</a></li>
                            <li><a href="<?php echo url('/ui-modal');; ?>">Modal</a></li>
                            <li><a href="<?php echo url('/ui-button-group');; ?>">Button Group</a></li>
                            <li><a href="<?php echo url('/ui-list-group');; ?>">List Group</a></li>
                            <li><a href="<?php echo url('/ui-media-object');; ?>">Media Object</a></li>
                            <li><a href="<?php echo url('/ui-card');; ?>">Cards</a></li>
                            <li><a href="<?php echo url('/ui-carousel');; ?>">Carousel</a></li>
                            <li><a href="<?php echo url('/ui-dropdown');; ?>">Dropdown</a></li>
                            <li><a href="<?php echo url('/ui-popover');; ?>">Popover</a></li>
                            <li><a href="<?php echo url('/ui-progressbar');; ?>">Progressbar</a></li>
                            <li><a href="<?php echo url('/ui-tab');; ?>">Tab</a></li>
                            <li><a href="<?php echo url('/ui-typography');; ?>">Typography</a></li>
                            <li><a href="<?php echo url('/ui-pagination');; ?>">Pagination</a></li>
                            <li><a href="<?php echo url('/ui-grid');; ?>">Grid</a></li>

                        </ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Plugins</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo url('/uc-select2');; ?>">Select 2</a></li>
                            <li><a href="<?php echo url('/uc-nestable');; ?>">Nestedable</a></li>
                            <li><a href="<?php echo url('/uc-noui-slider');; ?>">Noui Slider</a></li>
                            <li><a href="<?php echo url('/uc-sweetalert');; ?>">Sweet Alert</a></li>
                            <li><a href="<?php echo url('/uc-toastr');; ?>">Toastr</a></li>
                            <li><a href="<?php echo url('/map-jqvmap');; ?>">Jqv Map</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo url('/widget-basic');; ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Widget</span>
						</a>
					</li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Forms</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo url('/form-element');; ?>">Form Elements</a></li>
                            <li><a href="<?php echo url('/form-wizard');; ?>">Wizard</a></li>
                            <li><a href="<?php echo url('/form-editor-summernote');; ?>">Summernote</a></li>
                            <li><a href="<?php echo url('/form-pickers');; ?>">Pickers</a></li>
                            <li><a href="<?php echo url('/form-validation-jquery');; ?>">Jquery Validate</a></li>
                        </ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Table</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo url('/table-bootstrap-basic');; ?>">Bootstrap</a></li>
                            <li><a href="<?php echo url('/table-datatable-basic');; ?>">Datatable</a></li>
                        </ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-layer-1"></i>
							<span class="nav-text">Pages</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo url('/page-register');; ?>">Register</a></li>
                            <li><a href="<?php echo url('/page-login');; ?>">Login</a></li>
                            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Error</a>
                                <ul aria-expanded="false">
                                    <li><a href="<?php echo url('/page-error-400');; ?>">Error 400</a></li>
                                    <li><a href="<?php echo url('/page-error-403');; ?>">Error 403</a></li>
                                    <li><a href="<?php echo url('/page-error-404');; ?>">Error 404</a></li>
                                    <li><a href="<?php echo url('/page-error-500');; ?>">Error 500</a></li>
                                    <li><a href="<?php echo url('/page-error-503');; ?>">Error 503</a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo url('/page-lock-screen');; ?>">Lock Screen</a></li>
                        </ul>
                    </li> -->
                </ul>
            
				<!-- <div class="plus-box">
					<p class="fs-13 font-w300 mb-4">Organize your menus through button bellow</p>
					<a class="btn bg-white text-black btn-rounded d-block" href="javascript:;">+Add Menus</a>
				</div> -->
				<div class="copyright">
					<p class="fs-14 font-w200"><strong class="font-w400">WOLFPOS Restaurant Admin Dashboard</strong> © 2021 All Rights Reserved</p>
					<p>Made with <i class="fa fa-heart"></i> by </p>
				</div>
			</div>
        </div><?php /**PATH E:\foodAdmin\resources\views/elements/sidebar.blade.php ENDPATH**/ ?>
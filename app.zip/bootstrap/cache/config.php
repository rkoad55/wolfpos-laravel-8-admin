<?php return array (
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:N88eUqddKFi7XhtHtS+8tCTM8mCVDSwSmUuJ4vgFDrI=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\AppServiceProvider',
      23 => 'App\\Providers\\AuthServiceProvider',
      24 => 'App\\Providers\\EventServiceProvider',
      25 => 'App\\Providers\\RouteServiceProvider',
      26 => 'Collective\\Html\\HtmlServiceProvider',
      27 => 'Laravel\\Passport\\PassportServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
      'Passport' => 'Illuminate\\Support\\Facades\\Passport',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
        'hash' => false,
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
      'machines' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\MachinesModel',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'useTLS' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'D:\\foodAdmin\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
    ),
    'prefix' => 'laravel_cache',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'foodAppAdmin',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'foodAppAdmin',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'foodAppAdmin',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'foodAppAdmin',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'laravel_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'dz' => 
  array (
    'name' => 'Laravel',
    'public' => 
    array (
      'favicon' => 'media/img/logo/favicon.ico',
      'fonts' => 
      array (
        'google' => 
        array (
          'families' => 
          array (
            0 => 'Poppins:300,400,500,600,700',
          ),
        ),
      ),
      'global' => 
      array (
        'css' => 
        array (
          0 => 'css/style.css',
        ),
        'js' => 
        array (
          0 => 'vendor/global/global.min.js',
        ),
      ),
      'pagelevel' => 
      array (
        'css' => 
        array (
          'dashboard_1' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'https://cdn.lineicons.com/2.0/LineIcons.css',
          ),
          'analytics' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/jqvmap/css/jqvmap.min.css',
            2 => 'vendor/chartist/css/chartist.min.css',
            3 => 'https://cdn.lineicons.com/2.0/LineIcons.css',
          ),
          'customer_list' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/jqvmap/css/jqvmap.min.css',
            2 => 'vendor/datatables/css/jquery.dataTables.min.css',
            3 => 'vendor/chartist/css/chartist.min.css',
            4 => 'https://cdn.lineicons.com/2.0/LineIcons.css',
          ),
          'order' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/jqvmap/css/jqvmap.min.css',
            2 => 'vendor/chartist/css/chartist.min.css',
            3 => 'https://cdn.lineicons.com/2.0/LineIcons.css',
          ),
          'order_list' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/jqvmap/css/jqvmap.min.css',
            2 => 'vendor/datatables/css/jquery.dataTables.min.css',
            3 => 'vendor/chartist/css/chartist.min.css',
            4 => 'https://cdn.lineicons.com/2.0/LineIcons.css',
          ),
          'review' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/jqvmap/css/jqvmap.min.css',
            2 => 'vendor/chartist/css/chartist.min.css',
            3 => 'https://cdn.lineicons.com/2.0/LineIcons.css',
          ),
          'koki_element' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/chartist/css/chartist.min.css',
          ),
          'app_calender' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/fullcalendar/css/fullcalendar.min.css',
          ),
          'app_profile' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'chart_chartist' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/chartist/css/chartist.min.css',
          ),
          'chart_chartjs' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'chart_flot' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'chart_morris' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'chart_peity' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'chart_sparkline' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ecom_checkout' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ecom_customers' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ecom_invoice' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ecom_product_detail' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ecom_product_grid' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ecom_product_list' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ecom_product_order' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'email_compose' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/dropzone/dist/dropzone.css',
          ),
          'email_inbox' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'email_read' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'form_editor_summernote' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/summernote/summernote.css',
          ),
          'form_element' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'form_pickers' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/bootstrap-daterangepicker/daterangepicker.css',
            2 => 'vendor/clockpicker/css/bootstrap-clockpicker.min.css',
            3 => 'vendor/jquery-asColorPicker/css/asColorPicker.min.css',
            4 => 'vendor/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css',
            5 => 'vendor/pickadate/themes/default.css',
            6 => 'vendor/pickadate/themes/default.date.css',
          ),
          'form_validation_jquery' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'form_wizard' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/jquery-steps/css/jquery.steps.css',
          ),
          'map_jqvmap' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/jqvmap/css/jqvmap.min.css',
          ),
          'table_bootstrap_basic' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'table_datatable_basic' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/datatables/css/jquery.dataTables.min.css',
          ),
          'uc_nestable' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/nestable2/css/jquery.nestable.min.css',
          ),
          'uc_noui_slider' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/nouislider/nouislider.min.css',
          ),
          'uc_select2' => 
          array (
            0 => 'vendor/select2/css/select2.min.css',
          ),
          'uc_sweetalert' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/sweetalert2/dist/sweetalert2.min.css',
          ),
          'uc_toastr' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/toastr/css/toastr.min.css',
          ),
          'ui_accordion' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_alert' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_badge' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_button' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_button_group' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_card' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_carousel' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_dropdown' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_grid' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_list_group' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_media_object' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_modal' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_pagination' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_popover' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_progressbar' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_tab' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'ui_typography' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
          ),
          'widget_basic' => 
          array (
            0 => 'vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
            1 => 'vendor/chartist/css/chartist.min.css',
          ),
        ),
        'js' => 
        array (
          'dashboard_1' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/dashboard/dashboard-1.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'analytics' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/peity/jquery.peity.min.js',
            4 => 'js/dashboard/analytics.js',
            5 => 'js/custom.min.js',
            6 => 'js/deznav-init.js',
          ),
          'customer_list' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/datatables/js/jquery.dataTables.min.js',
            2 => 'js/custom.min.js',
            3 => 'js/deznav-init.js',
          ),
          'order' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/dashboard/order.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'order_list' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/datatables/js/jquery.dataTables.min.js',
            2 => 'js/custom.min.js',
            3 => 'js/deznav-init.js',
          ),
          'review' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'js/custom.min.js',
            2 => 'js/deznav-init.js',
          ),
          'koki_element' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/chartist/js/chartist.min.js',
            4 => 'vendor/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js',
            5 => 'vendor/flot/jquery.flot.js',
            6 => 'vendor/flot/jquery.flot.pie.js',
            7 => 'vendor/flot/jquery.flot.resize.js',
            8 => 'vendor/flot-spline/jquery.flot.spline.min.js',
            9 => 'vendor/jquery-sparkline/jquery.sparkline.min.js',
            10 => 'js/plugins-init/sparkline-init.js',
            11 => 'vendor/peity/jquery.peity.min.js',
            12 => 'js/plugins-init/piety-init.js',
            13 => 'js/custom.min.js',
            14 => 'js/deznav-init.js',
          ),
          'app_calender' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/jqueryui/js/jquery-ui.min.js',
            4 => 'vendor/moment/moment.min.js',
            5 => 'vendor/fullcalendar/js/fullcalendar.min.js',
            6 => 'js/plugins-init/fullcalendar-init.js',
            7 => 'js/custom.min.js',
            8 => 'js/deznav-init.js',
          ),
          'app_profile' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'chart_chartist' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/chartist/js/chartist.min.js',
            4 => 'vendor/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js',
            5 => 'js/plugins-init/chartist-init.js',
            6 => 'js/custom.min.js',
            7 => 'js/deznav-init.js',
          ),
          'chart_chartjs' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/plugins-init/chartjs-init.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'chart_flot' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/flot/jquery.flot.js',
            4 => 'vendor/flot/jquery.flot.pie.js',
            5 => 'vendor/flot/jquery.flot.resize.js',
            6 => 'vendor/flot-spline/jquery.flot.spline.min.js',
            7 => 'js/plugins-init/flot-init.js',
            8 => 'js/custom.min.js',
            9 => 'js/deznav-init.js',
          ),
          'chart_morris' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
            5 => 'vendor/raphael/raphael.min.js',
            6 => 'vendor/morris/morris.min.js',
            7 => 'js/plugins-init/morris-init.js',
          ),
          'chart_peity' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/peity/jquery.peity.min.js',
            4 => 'js/plugins-init/piety-init.js',
            5 => 'js/custom.min.js',
            6 => 'js/deznav-init.js',
          ),
          'chart_sparkline' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/jquery-sparkline/jquery.sparkline.min.js',
            4 => 'js/plugins-init/sparkline-init.js',
            5 => 'vendor/svganimation/vivus.min.js',
            6 => 'vendor/svganimation/svg.animation.js',
            7 => 'js/custom.min.js',
            8 => 'js/deznav-init.js',
          ),
          'ecom_checkout' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/highlightjs/highlight.pack.min.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'ecom_customers' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/highlightjs/highlight.pack.min.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'ecom_invoice' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/highlightjs/highlight.pack.min.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'ecom_product_detail' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/highlightjs/highlight.pack.min.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'ecom_product_grid' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/highlightjs/highlight.pack.min.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'ecom_product_list' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/highlightjs/highlight.pack.min.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'ecom_product_order' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/highlightjs/highlight.pack.min.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'email_compose' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/dropzone/dist/dropzone.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'email_inbox' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'email_read' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'form_editor_summernote' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/summernote/js/summernote.min.js',
            4 => 'js/plugins-init/summernote-init.js',
            5 => 'js/custom.min.js',
            6 => 'js/deznav-init.js',
          ),
          'form_element' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'form_pickers' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/moment/moment.min.js',
            4 => 'vendor/bootstrap-daterangepicker/daterangepicker.js',
            5 => 'vendor/clockpicker/js/bootstrap-clockpicker.min.js',
            6 => 'vendor/jquery-asColor/jquery-asColor.min.js',
            7 => 'vendor/jquery-asGradient/jquery-asGradient.min.js',
            8 => 'vendor/jquery-asColorPicker/js/jquery-asColorPicker.min.js',
            9 => 'vendor/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js',
            10 => 'vendor/pickadate/picker.js',
            11 => 'vendor/pickadate/picker.time.js',
            12 => 'vendor/pickadate/picker.date.js',
            13 => 'js/plugins-init/bs-daterange-picker-init.js',
            14 => 'js/plugins-init/clock-picker-init.js',
            15 => 'js/plugins-init/jquery-asColorPicker.init.js',
            16 => 'js/plugins-init/material-date-picker-init.js',
            17 => 'js/plugins-init/pickadate-init.js',
            18 => 'js/custom.min.js',
            19 => 'js/deznav-init.js',
          ),
          'form_validation_jquery' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/jquery-validation/jquery.validate.min.js',
            4 => 'js/plugins-init/jquery.validate-init.js',
            5 => 'js/custom.min.js',
            6 => 'js/deznav-init.js',
          ),
          'form_wizard' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/jquery-steps/build/jquery.steps.min.js',
            4 => 'vendor/jquery-validation/jquery.validate.min.js',
            5 => 'js/plugins-init/jquery.validate-init.js',
            6 => 'js/plugins-init/jquery-steps-init.js',
            7 => 'js/custom.min.js',
            8 => 'js/deznav-init.js',
          ),
          'map_jqvmap' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/jqvmap/js/jquery.vmap.min.js',
            4 => 'vendor/jqvmap/js/jquery.vmap.world.js',
            5 => 'vendor/jqvmap/js/jquery.vmap.usa.js',
            6 => 'js/plugins-init/jqvmap-init.js',
            7 => 'js/custom.min.js',
            8 => 'js/deznav-init.js',
          ),
          'page_error_400' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'page_error_403' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'page_error_404' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'page_error_500' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'page_error_503' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'page_forgot_password' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'page_lock_screen' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/deznav/deznav.min.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'page_login' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'page_register' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'table_bootstrap_basic' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'table_datatable_basic' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/datatables/js/jquery.dataTables.min.js',
            4 => 'js/plugins-init/datatables.init.js',
            5 => 'js/custom.min.js',
            6 => 'js/deznav-init.js',
          ),
          'uc_nestable' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/nestable2/js/jquery.nestable.min.js',
            4 => 'js/plugins-init/nestable-init.js',
            5 => 'js/custom.min.js',
            6 => 'js/deznav-init.js',
          ),
          'uc_noui_slider' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/nouislider/nouislider.min.js',
            4 => 'vendor/wnumb/wNumb.js',
            5 => 'js/plugins-init/nouislider-init.js',
            6 => 'js/custom.min.js',
            7 => 'js/deznav-init.js',
          ),
          'uc_select2' => 
          array (
            0 => 'vendor/select2/js/select2.full.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/plugins-init/select2-init.js',
            4 => 'js/custom.min.js',
            5 => 'js/deznav-init.js',
          ),
          'uc_sweetalert' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/sweetalert2/dist/sweetalert2.min.js',
            4 => 'js/plugins-init/sweetalert.init.js',
            5 => 'js/custom.min.js',
            6 => 'js/deznav-init.js',
          ),
          'uc_toastr' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/toastr/js/toastr.min.js',
            4 => 'js/plugins-init/toastr-init.js',
            5 => 'js/custom.min.js',
            6 => 'js/deznav-init.js',
          ),
          'ui_accordion' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_alert' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_badge' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_button' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_button_group' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_card' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_carousel' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_dropdown' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_grid' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_list_group' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_media_object' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_modal' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_pagination' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_popover' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_progressbar' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_tab' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'ui_typography' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'js/custom.min.js',
            4 => 'js/deznav-init.js',
          ),
          'widget_basic' => 
          array (
            0 => 'vendor/bootstrap-select/dist/js/bootstrap-select.min.js',
            1 => 'vendor/chart.js/Chart.bundle.min.js',
            2 => 'vendor/apexchart/apexchart.js',
            3 => 'vendor/chartist/js/chartist.min.js',
            4 => 'vendor/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js',
            5 => 'vendor/flot/jquery.flot.js',
            6 => 'vendor/flot/jquery.flot.pie.js',
            7 => 'vendor/flot/jquery.flot.resize.js',
            8 => 'vendor/flot-spline/jquery.flot.spline.min.js',
            9 => 'vendor/jquery-sparkline/jquery.sparkline.min.js',
            10 => 'js/plugins-init/sparkline-init.js',
            11 => 'vendor/peity/jquery.peity.min.js',
            12 => 'js/plugins-init/piety-init.js',
            13 => 'js/plugins-init/widgets-script-init.js',
            14 => 'js/custom.min.js',
            15 => 'js/deznav-init.js',
          ),
        ),
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\foodAdmin\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\foodAdmin\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      'image' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\foodAdmin\\public\\/images',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
      ),
    ),
    'links' => 
    array (
      'D:\\foodAdmin\\public\\storage' => 'D:\\foodAdmin\\storage\\app/public',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'D:\\foodAdmin\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'D:\\foodAdmin\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'D:\\foodAdmin\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.mailtrap.io',
        'port' => '2525',
        'encryption' => NULL,
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'auth_mode' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
    ),
    'from' => 
    array (
      'address' => NULL,
      'name' => 'Laravel',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'D:\\foodAdmin\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'suffix' => NULL,
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'receiptprinter' => 
  array (
    'connector_type' => 'network',
    'connector_descriptor' => '192.168.50.196',
    'connector_port' => 9100,
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => 'localhost',
    ),
    'expiration' => NULL,
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'D:\\foodAdmin\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'D:\\foodAdmin\\resources\\views',
    ),
    'compiled' => 'D:\\foodAdmin\\storage\\framework\\views',
  ),
  'flare' => 
  array (
    'key' => NULL,
    'reporting' => 
    array (
      'anonymize_ips' => true,
      'collect_git_information' => false,
      'report_queries' => true,
      'maximum_number_of_collected_queries' => 200,
      'report_query_bindings' => true,
      'report_view_data' => true,
      'grouping_type' => NULL,
      'report_logs' => true,
      'maximum_number_of_collected_logs' => 200,
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'light',
    'enable_share_button' => true,
    'register_commands' => false,
    'ignored_solution_providers' => 
    array (
      0 => 'Facade\\Ignition\\SolutionProviders\\MissingPackageSolutionProvider',
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'passport' => 
  array (
    'private_key' => NULL,
    'public_key' => NULL,
    'client_uuids' => false,
    'personal_access_client' => 
    array (
      'id' => NULL,
      'secret' => NULL,
    ),
    'storage' => 
    array (
      'database' => 
      array (
        'connection' => 'mysql',
      ),
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 94,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);

(function($) {
    "use strict"

    new dezSettings({
        version: "light"
    });


})(jQuery);
(function($) {
    "use strict"

    new dezSettings({
        headerPosition: "fixed",
    });


})(jQuery);
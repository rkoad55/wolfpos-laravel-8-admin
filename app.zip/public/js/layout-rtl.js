(function($) {
    "use strict"

    new dezSettings({
        direction: "rtl"
    });


})(jQuery);